package application;
import javafx.scene.paint.Color;
public class Pelota {
	private double x;
	private double y;
	private double radio;
	private double vX;
	private double vY;
	private int ultimoGolpe;
	private Color color;
	public Pelota(double r) {
		x = 321;
		y = 210;
		radio = r;
		vY  = -2 ;
		int rand =  (int)(Math.random()*100);
		if(rand%2==0) {
			ultimoGolpe = 1;
			vX = 2;
		}
		else {
			ultimoGolpe = 2;
			vX = -2;
		}
	}


	public double getX() {
	return x;

	}

	public double getY() {
	return y;

	}

	public double getRadio() {
	return radio;

	}
	public Color getColor() {
		return color;
	}
	private void rebotePared() {
	if(y<=0 || y>=410) {
		vY = -vY;
	}
}

	public int getGolpe() {
	return ultimoGolpe;

	}

	public void movimiento() {
	rebotePared();
	x += vX;
	y += vY;

	}

	public void cambiarSentido() {
	if(vX<0)vX =  -vX+1;
	else 
		if(vX>0)vX =- vX-1;
		if(ultimoGolpe==1)ultimoGolpe=2;
		else ultimoGolpe=1;
		if((int)vX/5 > 1)vY = (int)vX/3;

	}
}

