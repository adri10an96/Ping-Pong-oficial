package application;
	
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;


public class Main extends Application {
	
	private Pane root;	
	private Raqueta player1, player2;
	private Rectangle p1, p2;
	private Scene pantalla;
	private AnimationTimer timer;
	private Pelota bola;
	private Circle circulo;
	private Text puntaje1, puntaje2;
	private boolean muerte = false;
	private Button boton;
	
	private void updatePlayers() { //Actualiza las posiciones de raquetas y pelotas (Usando informacion de los objetos)
    	p1.setTranslateX(player1.getX());
    	p1.setTranslateY(player1.getY());
    	p2.setTranslateX(player2.getX());
    	p2.setTranslateY(player2.getY());
    	circulo.setTranslateX(bola.getX());
    	circulo.setTranslateY(bola.getY());
    }
    
    private boolean hayColision() { //Chequea si existe una colision entre raqueta y bola
    	if(circulo.getTranslateX() - p1.getTranslateX() <= circulo.getRadius() && bola.getGolpe()!=1) {
    		if(circulo.getTranslateY() >= p1.getTranslateY() && p1.getTranslateY()+120 >= circulo.getTranslateY())
    			return true;
    		else {
    			muerte = true;
    		}
    	}
    	if(p2.getTranslateX() - circulo.getTranslateX() <= circulo.getRadius() && bola.getGolpe()!=2) {
    		if(circulo.getTranslateY() >= p2.getTranslateY() && p2.getTranslateY()+120 >= circulo.getTranslateY())
    			return true;
    		else {
    			muerte = true;
    		}
    	}
    	return false;
    }
    
    private void reboteRaqueta() { // Ve si la bola debe rebotar en raqueta
		if(hayColision()) {
			bola.cambiarSentido();
		}
	}
    
    private void ganaste(String mensaje){ //Lanza el mensaje final
		timer.stop();
		Text a = new Text();
		a.setFont(new Font(55));
		a.setTranslateX(150);
		a.setTranslateY(210);
		a.setFill(Color.BLACK);
		a.setText(mensaje);
		root.getChildren().add(a);
	}
    private void moverBola() { //Movimiento constante, 60 veces al segundo
    	bola.movimiento();
    	reboteRaqueta();
    	updatePlayers();
    	if(muerte) {
    		if(bola.getGolpe()==2) {
    			player2.win();
    			puntaje2.setText(String.valueOf(player2.getPuntaje()));
    		}
    		if(bola.getGolpe()==1) {
    			player1.win();
    			puntaje1.setText(String.valueOf(player1.getPuntaje()));
    		}
    		if(player1.getPuntaje() == 2) {
    			ganaste("GANA JUGADOR 1");
    		//	timer.stop();
    		}
    		if(player2.getPuntaje() == 2) {
    	  		ganaste("GANA JUGADOR 1");
    		//	timer.stop();
    		}
    	
	
    		try{
    			
    			Thread.sleep(1250);
    		} catch(java.lang.InterruptedException i){
    			
    		}
 		initSet();
    	}
	}
    
    private void initSet() {//Inicia el set del juego
    	bola =  new Pelota(20.0);
    	circulo.setTranslateX(bola.getX());
    	circulo.setTranslateY(bola.getY());
		p1.setTranslateX(player1.getX());
		p1.setTranslateY(player1.getY());
		p2.setTranslateX(player2.getX());
		p2.setTranslateY(player2.getY());
		p1.setFill(player1.getColor());
		p2.setFill(player2.getColor());
		muerte = false;
    }
    
    private void initPuntaje(){ //INicia el puntaje de los jugadores, y los pone en pantalla
    	puntaje1.setText(String.valueOf(player1.getPuntaje()));
		puntaje2.setText(String.valueOf(player2.getPuntaje()));
		puntaje1.setFont(new Font(30)); puntaje2.setFont(new Font(30));
		puntaje1.setTranslateX(280); puntaje1.setTranslateY(450);
		puntaje2.setTranslateX(350); puntaje2.setTranslateY(450);
    }
    
    @Override
    public void start(Stage primaryStage) throws Exception{ //Main, por asi decirlo
    	root = new Pane();
    	root.setPrefSize(642, 450);
    	player1 = new Raqueta(1, Color.RED);
    	player2 = new Raqueta(2, Color.BLUE);
    	circulo = new Circle(15.0, Color.GREEN);
		puntaje1 = new Text(); 
		puntaje2 = new Text();
		p1 = new Rectangle(12, 80);
		p2 = new Rectangle(12, 80);
		initSet();
		initPuntaje();
    	timer = new AnimationTimer() {
    		@Override
    		public void handle(long now) {
    			moverBola();
    		}    	};
    	timer.start();
    	primaryStage.setTitle("Pong");
    	root.getChildren().addAll(p1, p2, circulo, puntaje1, puntaje2);
    	pantalla = new Scene(root);
    	primaryStage.setScene(pantalla);
    	primaryStage.setResizable(false);
    	primaryStage.getScene().setOnKeyPressed(event -> {
            switch (event.getCode()) {
                case W:
                   	player1.moverArriba();
                    break;
                case S:
                	player1.moverAbajo();
                    break;
                case O:
                    player2.moverArriba();
                    break;
                case L:
                    player2.moverAbajo();             
                default:
                    break;
            }
        });
    	primaryStage.show();
    }
    public static void main(String[] args) {
        launch(args);
    }
}
