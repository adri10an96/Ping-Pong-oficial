package application;

import javafx.scene.paint.Color;

public class Raqueta {
	private int puntaje;
	private double x;
	private double y;
	private Color color;
	public Raqueta(int player, Color col) {
		color = col;
		y = 150;
		if(player==1) {
			x = 10;
		}
		else {
			x = 630;
		}
		puntaje = 0;
	}
	public Color getColor() {
		return color;
	}
	public double getX() {
		return x;
	}
	public double getY() {
		return y;
	}
	public int getPuntaje() {
		return puntaje;
	}
	public void moverArriba(){
		y -= 20;
		if(y<0)y=0;
	}
	public void win() {
		puntaje++;
	}
	public void moverAbajo(){
		y += 20;
		if(y+120>420)y=300;
	}

}
